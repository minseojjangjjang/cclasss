#include <stdio.h>

int main()
{
	int confession;
	scanf("%d",&confession);
        if(confession)
	{
		printf("고백해도 모쏠이다 이놈들아");
	}
	else
	{
		printf("그래 나 모쏠이다 나쁜놈들아");
	}

	printf("이슬희는 그렇게 슬프게 울었습니다..");

	return 0;
}
